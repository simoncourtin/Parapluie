﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace SeparateIntoFiles
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string StripAccent(string chaine) 
{
	// Déclaration de variables
	string accent = "ÀÁÂÃÄÅàáâãäåÒÓÔÕÖØòóôõöøÈÉÊËèéêëÌÍÎÏìíîïÙÚÛÜùúûüÿÑñÇç";
	string sansAccent = "AAAAAAaaaaaaOOOOOOooooooEEEEeeeeIIIIiiiiUUUUuuuuyNnCc";

	// Conversion des chaines en tableaux de caractères
	char[] tableauSansAccent = sansAccent.ToCharArray();
	char[] tableauAccent = accent.ToCharArray();

	// Pour chaque accent
	for(int i=0; i<accent.Length; i++) 
	{
		// Remplacement de l'accent par son équivalent sans accent dans la chaîne de caractères
		chaine = chaine.Replace(tableauAccent[i].ToString(), tableauSansAccent[i].ToString());
	}

	// Retour du résultat
	return chaine;
}
        private void button1_Click(object sender, EventArgs e)
        {

            StreamReader in_file = new StreamReader("C:/dic/org", Encoding.Default); //Open the dic file and set the encoding
            Encoding write_encoding = System.Text.Encoding.GetEncoding("iso-8859-1"); //define the robotix-compatible encoding			

            //files

            string word = "";
            string f_letter = "";
            string dir_type = ""; //length
            int length = 0;
            while (!in_file.EndOfStream)
            {
                word = in_file.ReadLine(); //Read the first word

                f_letter = word.Substring(0, 1); //take the first letter
                f_letter = StripAccent(f_letter); //and strip it of all it's accents

                length = word.Length;

                if (length < 2)
                    dir_type = "1-3";
                else
                    dir_type = (length - 1).ToString() + "-" + (length + 1).ToString();


                StreamWriter letters = new StreamWriter("C:/dic/let/" + f_letter + "." + dir_type + ".txt", true, write_encoding);//Open the outfile
                letters.Write(word + letters.NewLine);
                letters.Flush();
                letters.Close();

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
